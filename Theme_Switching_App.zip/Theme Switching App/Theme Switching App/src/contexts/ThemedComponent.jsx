import React from "react";
import { useThemeContext } from "./ThemeContext";

const ThemeComponent = () => {
    const {theme} = useThemeContext();

    return (
        <div className={`p-4 ${theme === 'dark' ? 'bg-gray-800 text-white' : 'bg-white text-black'} rounded-lg mt-4 border border-solid border-black rounded`}>
            <h2>this is the component</h2>           
            <h2>whose theme will be changed</h2>
        </div>
    )
}

export default ThemeComponent;